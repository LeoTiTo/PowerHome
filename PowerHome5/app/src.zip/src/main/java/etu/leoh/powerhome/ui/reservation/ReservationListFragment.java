package etu.leoh.powerhome.ui.reservation;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import etu.leoh.powerhome.R;
import etu.leoh.powerhome.model.DeviceReservation;
import etu.leoh.powerhome.model.User;
import etu.leoh.powerhome.repository.ReservationRepository;
import etu.leoh.powerhome.repository.UserRepository;
import etu.leoh.powerhome.ui.reservation.adapter.ReservationAdapter;
import etu.leoh.powerhome.util.ConsumptionCalculator;
import etu.leoh.powerhome.util.FirebaseAuthHelper;

/**
 * Fragment affichant la liste des réservations d'appareils de l'utilisateur
 */
public class ReservationListFragment extends Fragment implements ReservationAdapter.ReservationInteractionListener {

    private RecyclerView recyclerView;
    private ReservationAdapter adapter;
    private List<DeviceReservation> reservationList;
    private ProgressBar progressBar;
    private FloatingActionButton addReservationButton;
    
    private ReservationRepository reservationRepository;
    private UserRepository userRepository;
    private FirebaseAuthHelper authHelper;
    private ConsumptionCalculator consumptionCalculator;
    private User currentUser;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_reservation_list, container, false);
        
        // Initialiser les repositories et helpers
        reservationRepository = new ReservationRepository();
        userRepository = new UserRepository();
        authHelper = new FirebaseAuthHelper();
        consumptionCalculator = new ConsumptionCalculator();
        
        // Initialiser les vues
        recyclerView = view.findViewById(R.id.recyclerViewReservations);
        progressBar = view.findViewById(R.id.progressBar);
        addReservationButton = view.findViewById(R.id.fabAddReservation);
        
        // Configurer le RecyclerView
        reservationList = new ArrayList<>();
        adapter = new ReservationAdapter(reservationList, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);
        
        // Configurer le bouton d'ajout
        addReservationButton.setOnClickListener(v -> {
            startActivity(new Intent(getContext(), NewReservationActivity.class));
        });
        
        // Charger l'utilisateur actuel puis ses réservations
        loadCurrentUser();
        
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        // Recharger les réservations quand on revient sur ce fragment
        if (authHelper.isUserLoggedIn()) {
            loadReservations();
        }
    }

    /**
     * Charge les informations de l'utilisateur actuel
     */
    private void loadCurrentUser() {
        progressBar.setVisibility(View.VISIBLE);
        
        String userId = authHelper.getCurrentUserId();
        if (userId != null) {
            userRepository.getUserById(userId)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful() && task.getResult() != null) {
                            currentUser = task.getResult().toObject(User.class);
                            loadReservations();
                        } else {
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(getContext(), 
                                    "Erreur lors du chargement des données utilisateur", 
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
        } else {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(getContext(), "Utilisateur non connecté", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Charge la liste des réservations de l'utilisateur
     */
    private void loadReservations() {
        if (currentUser == null) {
            progressBar.setVisibility(View.GONE);
            return;
        }
        
        // Récupérer les réservations de l'utilisateur
        reservationRepository.getReservationsByUserId(currentUser.getId())
                .addOnCompleteListener(task -> {
                    progressBar.setVisibility(View.GONE);
                    
                    if (task.isSuccessful()) {
                        reservationList.clear();
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            DeviceReservation reservation = document.toObject(DeviceReservation.class);
                            reservationList.add(reservation);
                        }
                        adapter.notifyDataSetChanged();
                        
                        // Afficher un message si la liste est vide
                        if (reservationList.isEmpty()) {
                            Toast.makeText(getContext(), 
                                    "Aucune réservation trouvée. Créez-en une!", 
                                    Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getContext(), 
                                "Erreur lors du chargement des réservations: " + task.getException().getMessage(), 
                                Toast.LENGTH_LONG).show();
                    }
                });
    }

    /**
     * Marque une réservation comme terminée et attribue les éco-coins
     */
    private void completeReservation(DeviceReservation reservation) {
        // Vérifier si la réservation est déjà terminée
        if (reservation.isCompleted()) {
            Toast.makeText(getContext(), "Cette réservation est déjà terminée", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Afficher la barre de progression
        progressBar.setVisibility(View.VISIBLE);
        
        // Calculer le niveau de consommation actuel pour déterminer les éco-coins
        consumptionCalculator.calculateConsumptionLevel(new Date(), new ConsumptionCalculator.ConsumptionLevelCallback() {
            @Override
            public void onConsumptionLevelCalculated(double consumptionPercentage, DeviceReservation.ConsumptionLevel level) {
                // Calculer les éco-coins gagnés
                int ecoCoinsEarned = reservation.calculateEcoCoins(level);
                
                // Mettre à jour la réservation
                reservation.setCompleted(true);
                reservation.setEcoCoinsEarned(ecoCoinsEarned);
                
                // Enregistrer les modifications
                reservationRepository.updateReservation(reservation)
                        .addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                // Mettre à jour les éco-coins de l'utilisateur
                                int newEcoCoins = currentUser.getEcoCoins() + ecoCoinsEarned;
                                currentUser.setEcoCoins(newEcoCoins);
                                
                                userRepository.updateEcoCoins(currentUser.getId(), newEcoCoins)
                                        .addOnCompleteListener(updateTask -> {
                                            progressBar.setVisibility(View.GONE);
                                            
                                            if (updateTask.isSuccessful()) {
                                                adapter.notifyDataSetChanged();
                                                String message = ecoCoinsEarned >= 0 ? 
                                                        "Réservation terminée ! Vous avez gagné " + ecoCoinsEarned + " éco-coins." :
                                                        "Réservation terminée ! Vous avez perdu " + Math.abs(ecoCoinsEarned) + " éco-coins.";
                                                Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();
                                            } else {
                                                Toast.makeText(getContext(), 
                                                        "Erreur lors de la mise à jour des éco-coins: " + updateTask.getException().getMessage(), 
                                                        Toast.LENGTH_LONG).show();
                                            }
                                        });
                            } else {
                                progressBar.setVisibility(View.GONE);
                                Toast.makeText(getContext(), 
                                        "Erreur lors de la mise à jour de la réservation: " + task.getException().getMessage(), 
                                        Toast.LENGTH_LONG).show();
                            }
                        });
            }

            @Override
            public void onError(String errorMessage) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(getContext(), errorMessage, Toast.LENGTH_LONG).show();
            }
        });
    }

    /**
     * Supprime une réservation après confirmation
     */
    private void cancelReservation(DeviceReservation reservation) {
        // Vérifier si la réservation est déjà terminée
        if (reservation.isCompleted()) {
            Toast.makeText(getContext(), "Impossible d'annuler une réservation terminée", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Demander confirmation
        new android.app.AlertDialog.Builder(getContext())
                .setTitle("Annuler la réservation")
                .setMessage("Êtes-vous sûr de vouloir annuler cette réservation ?")
                .setPositiveButton("Annuler la réservation", (dialog, which) -> {
                    // Afficher la progression
                    progressBar.setVisibility(View.VISIBLE);
                    
                    // Supprimer la réservation
                    reservationRepository.deleteReservation(reservation.getId())
                            .addOnCompleteListener(task -> {
                                progressBar.setVisibility(View.GONE);
                                
                                if (task.isSuccessful()) {
                                    // Supprimer de la liste et rafraîchir
                                    reservationList.remove(reservation);
                                    adapter.notifyDataSetChanged();
                                    Toast.makeText(getContext(), "Réservation annulée avec succès", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(getContext(), 
                                            "Erreur lors de l'annulation de la réservation: " + task.getException().getMessage(), 
                                            Toast.LENGTH_LONG).show();
                                }
                            });
                })
                .setNegativeButton("Garder", null)
                .show();
    }

    // Implémentation des callbacks de l'adaptateur
    @Override
    public void onReservationComplete(DeviceReservation reservation) {
        completeReservation(reservation);
    }

    @Override
    public void onReservationCancel(DeviceReservation reservation) {
        cancelReservation(reservation);
    }
} 