package etu.leoh.powerhome.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import java.text.DateFormat;
import java.util.Date;

import etu.leoh.powerhome.R;
import etu.leoh.powerhome.model.DeviceReservation;
import etu.leoh.powerhome.ui.reservation.NewReservationActivity;
import etu.leoh.powerhome.util.ConsumptionCalculator;

/**
 * Fragment d'accueil affichant le niveau de consommation et les options principales
 */
public class HomeFragment extends Fragment {

    private ProgressBar consumptionProgressBar;
    private TextView consumptionLevelTextView;
    private TextView consumptionPercentageTextView;
    private TextView dateTextView;
    private Button bookDeviceButton;
    private CardView lowConsumptionCard, mediumConsumptionCard, highConsumptionCard;
    
    private ConsumptionCalculator consumptionCalculator;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        
        // Initialiser le calculateur de consommation
        consumptionCalculator = new ConsumptionCalculator();
        
        // Initialiser les vues
        consumptionProgressBar = view.findViewById(R.id.consumptionProgressBar);
        consumptionLevelTextView = view.findViewById(R.id.tvConsumptionLevel);
        consumptionPercentageTextView = view.findViewById(R.id.tvConsumptionPercentage);
        dateTextView = view.findViewById(R.id.tvDate);
        bookDeviceButton = view.findViewById(R.id.btnBookDevice);
        
        lowConsumptionCard = view.findViewById(R.id.cardLowConsumption);
        mediumConsumptionCard = view.findViewById(R.id.cardMediumConsumption);
        highConsumptionCard = view.findViewById(R.id.cardHighConsumption);
        
        // Afficher la date actuelle
        DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.MEDIUM);
        dateTextView.setText(dateFormat.format(new Date()));
        
        // Configurer le bouton de réservation
        bookDeviceButton.setOnClickListener(v -> {
            // Rediriger vers l'écran de nouvelle réservation
            startActivity(new Intent(getActivity(), NewReservationActivity.class));
        });
        
        // Charger les données de consommation
        loadConsumptionData();
        
        return view;
    }

    /**
     * Charge les données de consommation actuelle
     */
    private void loadConsumptionData() {
        // Obtenir la date actuelle
        Date now = new Date();
        
        // Afficher un indicateur de chargement
        consumptionProgressBar.setIndeterminate(true);
        consumptionLevelTextView.setText(R.string.loading);
        consumptionPercentageTextView.setText("");
        
        // Récupérer le niveau de consommation
        consumptionCalculator.calculateConsumptionLevel(now, new ConsumptionCalculator.ConsumptionLevelCallback() {
            @Override
            public void onConsumptionLevelCalculated(double consumptionPercentage, DeviceReservation.ConsumptionLevel level) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        // Mettre à jour l'UI avec les données de consommation
                        updateConsumptionUI(consumptionPercentage, level);
                    });
                }
            }

            @Override
            public void onError(String errorMessage) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        Toast.makeText(getActivity(), errorMessage, Toast.LENGTH_SHORT).show();
                        // En cas d'erreur, afficher un niveau par défaut
                        updateConsumptionUI(0, DeviceReservation.ConsumptionLevel.LOW);
                    });
                }
            }
        });
    }

    /**
     * Met à jour l'interface utilisateur avec les données de consommation
     */
    private void updateConsumptionUI(double consumptionPercentage, DeviceReservation.ConsumptionLevel level) {
        // Convertir le pourcentage en valeur entière (0-100)
        int percentage = (int) (consumptionPercentage * 100);
        
        // Mettre à jour la barre de progression
        consumptionProgressBar.setIndeterminate(false);
        consumptionProgressBar.setProgress(percentage);
        
        // Mettre à jour le texte du pourcentage
        consumptionPercentageTextView.setText(percentage + "%");
        
        // Mettre à jour le texte du niveau
        String levelText;
        
        // Mettre en évidence la carte correspondant au niveau de consommation
        lowConsumptionCard.setCardBackgroundColor(getResources().getColor(android.R.color.white));
        mediumConsumptionCard.setCardBackgroundColor(getResources().getColor(android.R.color.white));
        highConsumptionCard.setCardBackgroundColor(getResources().getColor(android.R.color.white));
        
        switch (level) {
            case LOW:
                levelText = getString(R.string.low_consumption);
                consumptionLevelTextView.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
                lowConsumptionCard.setCardBackgroundColor(getResources().getColor(android.R.color.holo_green_light));
                break;
            case MEDIUM:
                levelText = getString(R.string.medium_consumption);
                consumptionLevelTextView.setTextColor(getResources().getColor(android.R.color.holo_orange_dark));
                mediumConsumptionCard.setCardBackgroundColor(getResources().getColor(android.R.color.holo_orange_light));
                break;
            case HIGH:
                levelText = getString(R.string.high_consumption);
                consumptionLevelTextView.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
                highConsumptionCard.setCardBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
                break;
            default:
                levelText = getString(R.string.low_consumption);
                consumptionLevelTextView.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
                lowConsumptionCard.setCardBackgroundColor(getResources().getColor(android.R.color.holo_green_light));
                break;
        }
        
        consumptionLevelTextView.setText(levelText);
    }
} 